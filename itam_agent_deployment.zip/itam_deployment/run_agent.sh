#!/bin/bash
echo "Starting ITAM Agent..."
python3 itam_agent.py

