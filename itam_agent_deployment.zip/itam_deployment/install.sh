#!/bin/bash
echo "=========================================="
echo "   ITAM Agent Installer - Mac/Linux"
echo "=========================================="
echo ""
echo "Installing required packages..."
pip3 install psutil requests
echo ""
echo "Installation complete!"
echo ""
echo "To run the agent, use: python3 itam_agent.py"
echo ""

